<p align="left">
<a href="#"><img title="MADE IN PAKISTAN" src="https://img.shields.io/badge/MADE%20IN-PAKISTAN-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
<a href="#"><img title="MADE IN MUSLIM" src="https://img.shields.io/badge/MADE%20IN-MUSLIM-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
<p align="center">
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-green?style=for-the-badge"></a>
</p>

<p align="center">
 
<img src="https://i.pinimg.com/originals/16/62/ac/1662acee2dae9125798c9d54a6530333.gif">
 
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-2.0-green.svg?style=flat-square"></a>
<a href="#"><img title="Language" src="https://badges.frapsoft.com/bash/v1/bash.png?v=103"></a>
<a href="https://github.com/CLB-09/followers"><img title="Followers" src="https://img.shields.io/github/followers/CLB-09?color=blue&style=flat-square"></a>
<a href="https://github.com/CLB-09/track-ip/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/CLB-09/track-ip?color=red&style=flat-square"></a>
<a href="https://github.com/CLB-09/track-ip/network/members"><img title="Forks" src="https://img.shields.io/github/forks/CLB-09/track-ip?color=red&style=flat-square"></a>
<a href="https://github.com/CLB-09/track-ip/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/CLB-09/track-ip?label=Watchers&color=blue&style=flat-square"></a>
</p>

<h1 align="center">(CLB-09 BRAND)</h1>
<p align="center"><a href="https://github.com/CLB-09">
<img height="165" src="https://github-readme-stats.vercel.app/api?username=CLB-09&show_icons=true&include_all_commits=true&theme=react&cache_seconds=3200&hide_border=true" /></a>
   
<a href="https://github.com/CLB-09"><img src="https://github-readme-stats.vercel.app/api/top-langs/?username=CLB-09&layout=compact&theme=react&hide_border=true" />
</a></p>
 
<h2><b><i>Howdy , it's CLB-09 👋</i></b></h2>
<b><i>💻 I'm a Shop Kipper Ladies Clothes</i></b>

<p align="center">
<img width="50%" src="src/B612_20211026_224517_347.jpg"/>

<img width="50%" src="src/FB_IMG_1564401174856.jpg"/> 

<img width="50%" src="src/FB_IMG_1632865348654.jpg"/>

<img width="50%" src="src/FB_IMG_1632865365791.jpg"/>

<img width="100%" src="src/IMG_20211001_172847.jpg"/>

<img width="50%" src="src/IMG_20211011_172544_656.jpg"/>

<img width="50%" src="src/IMG_20211011_172544_678.jpg"/>

<img width="50%" src="src/PicsArt_09-28-03.19.53.jpg"/>

<img width="50%" src="src/PicsArt_10-17-03.38.10.jpg"/>

<img width="50%" src="src/PicsArt_21-10-26_22-53-00-591.jpg"/>

<img width="50%" src="src/PicsArt_21-11-02_02-25-12-596.jpg"/>

<img width="100%" src="src/Snapchat-1035004743.jpg"/>

<img width="50%" src="src/Snapchat-1353345931.jpg"/>

<img width="50%" src="src/Snapchat-1754969058.jpg"/>

<img width="50%" src="src/Snapchat-1761384633.jpg"/>

<img width="50%" src="src/Snapchat-1911495809.jpg"/>

<img width="50%" src="src/Snapchat-254553157.jpg"/>

<img width="50%" src="src/Snapchat-370131057.jpg"/>

<img width="100%" src="src/Snapchat-766332371.jpg"/>
</p>

<img width="50%" src="src/Snapchat-1867191008.jpg."/>
</p>

<img width="100%" src="src/Snapchat-1776684485.jpg"/>
</p>

<img width="150%" src="src/Snapchat-2033630241.jpg"/>
</p>

<img width="100%" src="src/FB_IMG_1642539227291.jpg"/>
</p>

<h3><b><i>🤠 About me :</i></b></h3>
<li> 🇵🇰 <i>Resident of Pakistan</i></li>
<li> 😇 <i>Muslim</i></li>
<li> 😐 <i>Studying at Britannica End</i></li>
<li> 😪 <i>Love Sleeping</i></li>
<li> 💞 <i>Born Engage</i></li>
<li> 🐍 <i>Trying to learn Python & HTML</i></li>
<li> 🤐 <i>Aim : Become a Software Engineer</i></li>
 
 
<h3><b><i>🏆 Github Statistics :</i></b></h3>
<a href="https://github.com/CLB-09"><img width=550 src="https://github-profile-trophy.vercel.app/?username=CLB-09&theme=dracula&no-frame=true&title=Followers,Stars,Commit,Repository,Issues"/></a>
 
<h3><b><i>🏆 Profile Statistics :</i></b></h3>
<a href="https://github.com/CLB-09"><img height="25" title="Counter" src="https://komarev.com/ghpvc/?username=CLB-09&color=blueviolet&style=flat-square"></a>
 
## Find Me on :
[![Github](https://img.shields.io/badge/Github-CLB--09-green?style=for-the-badge&logo=github)](https://github.com/CLB-09)
[![Instagram](https://img.shields.io/badge/IG-%40abdulbasitkambo-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/abdulbasitkambo)
[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)](https://m.me/pythz)
[![SnakeVideo](https://img.shields.io/badge/Snake-Video-blue?style=for-the-badge&logo=Snakevideo)](https://sck.io/u/SP14hNBB)
